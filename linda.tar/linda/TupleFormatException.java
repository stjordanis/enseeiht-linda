package linda;

@SuppressWarnings("serial")
public class TupleFormatException extends IllegalArgumentException {
	
    public TupleFormatException(String s) {
        super(s);
    }

}
